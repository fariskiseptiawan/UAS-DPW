				</div><!-- /.content-wrapper -->

				<footer class="main-footer">
				    <div class="pull-right hidden-xs">
				        <b>Version</b> 2.0
				    </div>
				    <strong>Copyright &copy; 2014-2015 <a href="http://almsaeedstudio.com">Almsaeed Studio</a>.</strong> All rights reserved.
				</footer>
				</div><!-- ./wrapper -->

				<!-- jQuery 2.1.3 -->
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/plugins/jQuery/jQuery-2.1.3.min.js') ?>"></script>
				
				<!-- Bootstrap 3.3.2 JS -->
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/bootstrap/js/bootstrap.min.js') ?>" type="text/javascript"></script>
				<!-- SlimScroll -->
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/plugins/slimScroll/jquery.slimScroll.min.js') ?>" type="text/javascript"></script>
				<!-- FastClick -->
				<script src='<?php echo base_url('assets/AdminLTE-2.0.5/plugins/fastclick/fastclick.min.js') ?>'></script>
				<!-- AdminLTE App -->
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/dist/js/app.min.js') ?>" type="text/javascript"></script>
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/dist/js/sweetalert2.all.js') ?>" type="text/javascript"></script>
				<!-- AdminLTE App -->
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/dist/js/costum.js') ?>" type="text/javascript"></script>
				
				<script src="<?php echo base_url('assets/js-crip/jquery.dataTables.min.js') ?>" type="text/javascript"></script>
				
				<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
				
				<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" type="text/javascript"></script>
				
				<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>

				<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>

				<script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>

				<script src="//cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>

				<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.js"></script>

				<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.js"></script>

				<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>

				<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.js"></script>

				<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.js"></script>
				
				<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.js"></script>
				
				<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.bootstrap.js"></script>
				
				<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.js"></script>
				
				<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.js"></script>
				<script type="text/javascript" src="http://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
				<script src="<?php echo base_url('assets/AdminLTE-2.0.5/plugins/datepicker/bootstrap-datepicker.js') ?>" type="text/javascript"></script>
	</body>
</html>
